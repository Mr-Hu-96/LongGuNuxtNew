import{p as s}from"./BgIAKZ1C.js";const t=s("/images/user/empty.png");export{t as _};
