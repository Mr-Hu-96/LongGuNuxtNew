import{p as s}from"./BgIAKZ1C.js";const i=s("/images/user/time.png"),p=s("/images/user/view.png");export{i as _,p as a};
